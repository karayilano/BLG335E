Compile with "g++ 150140011.cpp -o hw2"
Then run "./hw2 events.txt"